import { ValidateRepPassDirective } from './validate-rep-pass.directive';

describe('ValidateRepPassDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidateRepPassDirective();
    expect(directive).toBeTruthy();
  });
});
