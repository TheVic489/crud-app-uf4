import { Component } from '@angular/core';

@Component({
  selector: 'app-insufficient-permissions',
  templateUrl: './insufficient-permissions.component.html',
  styleUrls: ['./insufficient-permissions.component.css']
})
export class InsufficientPermissionsComponent {

}
