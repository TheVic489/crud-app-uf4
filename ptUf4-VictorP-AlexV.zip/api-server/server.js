"use strict";
// Agafem en constants totes les llibreries
const express   = require("express");
const bodyParse = require("body-parser");
const mysql   	= require("mysql");
const path 		= require("path")
const app 		= express();
const jwt	    = require('jsonwebtoken');
const cors      = require('cors');

const accessTokenSecret = 'youraccesstokensecret';

const connection = mysql.createConnection({
	host: "localhost",
	database: "user-uf4",
	user: "vic",
	password: "123qwe",
});

app.use('/', express.static(path.join(__dirname, 'views/')))
//app.use(bodyParse.urlencoded({ extended: false }));
app.use(bodyParse.json());

// CORS POLICY //
app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
	next();
  });

// GET
app.get("/hello", (request, response) => {
	response.send({ message: "Hola mon! (GET)" });
});
app.get("/hello/:name", (name, response) => {
	var nom = name.params.name;
	response.send({ message: `Hola ${nom} (GET)` });
});

app.post("/login", function (req, res) {
	res.header('Access-Control-Allow-Headers', 'Authorization');
	console.log("estem a login");

	console.log(req.body);

	let username = req.body.username;
	let password = req.body.password;
	
	//provem de connectar-nos i capturar possibles errors
	connection.connect(function (err) {
		if (err) {
			console.error("Error connecting: " + err.stack);
			return;
		}
		console.log("Connected as id " + connection.threadId);
	});

	var sql = "SELECT * FROM user_table WHERE username =? AND password =?";

	connection.query(sql, [username, password], function (error, results, field) {

		if (error) {
			console.log(error);
			res.status(400).send(null);
		} else {
			/*COMPROVACIÓ DE DADES PER CONSOLA DE NODE*/
			   console.log(results);

			if (results != null) {
			// generem un token
			const accessToken = jwt.sign({ username: results.username,  role: results.role }, accessTokenSecret, {expiresIn: '1h'});
			//enviem el token
			res.status(200).send({ resultats: results, accessToken: accessToken});
			}
		}
	});

});

// REGISTER //
app.post("/register", function (req, res) {
	console.log("estem al registre");
	
	console.log(req.body.user);

	let all_name = req.body.user.full_name;
	let username = req.body.user.username;
	let password = req.body.user.password;
	let role     = req.body.user.role;
	let email    = req.body.user.email;
	let tel 	 = req.body.user.tel;
	
	//provem de connectar-nos i capturar possibles errors
	connection.connect(function (err) {
		if (err) {
			console.error("Error connecting: " + err.stack);
			return;
		}
		console.log("Connected as id " + connection.threadId);
	});

	var sql = "INSERT INTO user_table (all_name, username, password, role, email, tel) VALUES (?, ?, ?, ?, ?, ?);";

	connection.query(sql, [all_name, username, password, role, email, tel], function (error, results, field) {

		if (error) {
			console.log(error);
			res.status(400).send(null);
		} else {
			/*COMPROVACIÓ DE DADES PER CONSOLA DE NODE*/
			   console.log(results);

			if (results != null) {
			res.status(200).send({ resultats: results });
			}
		}
	});

	connection.end();

});

//creem una constant que farà de middleware a qui el faci servir (get i post de books)
const authenticateJWT = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (authHeader) {
        const token = authHeader.split(' ')[1];

        jwt.verify(token, accessTokenSecret, (err, user) => {
            if (err) {
                console.log(err)
                return res.sendStatus(403);
            }

            req.user = user;
            next();
        });
    } else {
        res.sendStatus(401);
    }
};

// GET TABLE
app.get("/api/bio_table", (req, res) => {
	// connection.connect(function (err) {
	//   if (err) {
	//     console.log("Error connectiong " + err.stack);
	//     return;
	//   }
	//   console.log("Connected as id: " + connection.threadId);
	// });
  
	connection.query("SELECT * FROM animals_bd", (error, results) => {
	  if (error) {
		res.status(400).send({ response: null });
	  } else {
		//Connection OK
		// res.status(200).send({ response: results });
		res.status(200).send(results);
		 
	  }
	});
  });

app.post("/delete", authenticateJWT, function (req, res) {

//recullo l'id
let Id = req.body.Id;


	connection.connect(function(err){
		if (err){
			console.error('Error connecting' + err.stack);
			return;
		}
		console.log('Connected as id' + connection.threadId);
	})

	//Consulta parametrizada
	var sql = 'DELETE FROM animals_bd WHERE Id=?';

	connection.query(sql, [Id],function(error, results){
		if (error) {
			res.status(400).send({ response: null });
			console.log(error)
		} else {
		//Connection OK
		console.log(results[0]);
		res.json(results[0]);
		}
	});

});

app.post("/update",  authenticateJWT, function(req,res){
	console.log('UPDATE animal')
	console.log(req.body)

	let id       = req.body.id
	let especie  = req.body.grup
	let cantidad = req.body.familia
	let familia  = req.body.especie
	let origen   = req.body.origen
	let habitat  = req.body.endemisme
	let ambient  = req.body.ambient
  
	var sql = 'UPDATE animals_bd SET Grup = ?, Familia = ?, Espècie = ?, Origen = ?, Endemisme = ?, Ambient = ? WHERE id = ?'
	connection.query(sql,[especie, cantidad, familia, origen, habitat, ambient, id],function(error,result){
	  if(error){
		console.log('incorrect')
		console.log(error)
	  }else{
		res.send({resultats: result})
	  }
	})
  })

  app.post("/insert/animal", authenticateJWT, function (req, res) {
  
	//recullo l'id
	let Grup = req.body.Grup;
	let Familia = req.body.Familia;
	let Especie = req.body.Especie;
	let Origen = req.body.Origen;
	let Endemisme = req.body.Endemisme;
	let Ambient = req.body.Ambient;
	  //Consulta parametrizada
	  var sql = 'INSERT INTO animals_bd (Grup, Familia, Espècie, Origen, Endemisme, Ambient) VALUES (?,?,?,?,?,?);';
  
	  connection.query(sql, [Grup, Familia, Especie, Origen, Endemisme, Ambient],function(error, results){
		  if (error) {
		  res.send('Id not found');
		  console.log(error)
		  } else {
		  //Connection OK
		  console.log(results[0]);
		  res.json(results[0]);
		  }
	  });
  
  });

  app.post("/select-where", authenticateJWT,function(req,res){
	console.log('Select animal')
	console.log(req.body)

	let id = req.body.id
  
	var sql = 'SELECT * FROM animals_bd WHERE id = ?'
	connection.query(sql,[id],function(error,result){
	  if(error){
		console.log('error:')
		console.log(error)
	  }else{
		console.log(result)
		res.send({result})
	  }
	})
  })
app.listen(3000, () => {
	console.log(
		"Aquesta és la nostra API-REST que corre en http://localhost:3000"
	);
});

// // POST
// app.post("/hello", (request, response) => {
// 	response.send({ message: "Hola mon! (POST)" });
// });
// app.post("/address", (request, response) => {
// 	// Recollim els valors que venen des d'un post (xhr.send)
// 	var recollida = request.body;
// 	var ciutat = request.body.ciutat;
// 	console.log(recollida, "\n", ciutat);

// 	response.send({ message: "Tot ok" });
// });
